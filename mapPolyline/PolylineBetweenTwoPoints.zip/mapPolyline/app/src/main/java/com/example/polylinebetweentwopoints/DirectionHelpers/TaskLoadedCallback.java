package com.example.polylinebetweentwopoints.DirectionHelpers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
